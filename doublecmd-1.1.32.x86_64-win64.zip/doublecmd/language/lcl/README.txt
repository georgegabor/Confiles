Language files in this directory are part of Lazarus.
This directory synchronized with current Lazarus version.
If you want to translate it then send translation to Lazarus project.

https://www.lazarus-ide.org
https://gitlab.com/freepascal.org/lazarus/lazarus/-/tree/main/lcl/languages
